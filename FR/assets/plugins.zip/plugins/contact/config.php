<?php

// Mail Setup
// ==========

// Your Email Address where new emails will be sent to
$to_email = 'y.gamin@mail.ru';

// Email Subject
$mail_subject = 'E-mail via GaminY';

// Email content can be modified in the sendmail.php file

?>